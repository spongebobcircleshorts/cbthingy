# Code by Sumedh Girish supporting text_adventure.py

dirn = {"east": (1, 0), "west": (-1, 0), "north": (0, -1), "south": (0, 1)}

main_passcode = "ahsian"

"""Moves player in specified direction if possible.

Checks if the direction is valid from the current node. 
If so, updates player's position coordinates accordingly.

Args:
 player: The Player instance
 direction: Direction to move, e.g. "north"
 c_node: The current Node the player is on

Returns:
 None
"""


def go(player, direction, c_node):
    if direction in c_node.possible_Directions():
        player.pos[0] += dirn[direction][0]
        player.pos[1] += dirn[direction][1]
        return "Success"
    return "Failed"


"""Teleports player to a node of specified type.

Searches through explored nodes to find one matching the given type.
Sets player's position to the position of that node.

Args:
 player: The Player instance
 typ: The node type to teleport to, e.g. "Fountain"

Returns:
 None  
"""


def teleport(player, typ):
    for node in player.explored_nodes.values():
        if node.type == typ:
            player.pos[0] = node.pos[0]
            player.pos[1] = node.pos[1]
            return "Success"
    return "Failed"


"""Adds grabable item from node to player's inventory.

Tries to retrieve the 'grab' action item from the node.
If successful, adds it to the player's inventory and 
removes it from the node's actions and content.

Args:
 player: The Player instance
 c_node: The current Node the player is on  

Returns:
 "Success" if item grabbed, else no return.
"""


def grab(player, c_node):
    try:
        player.inventory.append(c_node.actions["grab"][-1])
        del c_node.actions["grab"]
        del c_node.content[-1]["grab"]
        return "Success"
    except KeyError:
        return "Failed"


node_info = {
    (1, 4): (
        "Closet",
        [
            "You find yourself shriveled up in a cramped closet. You are disoriented and uncertain of your surroundings.",
            "The air is musty, and the walls are lined with forgotten trinkets. It appears to be hidden in the corner of a mansion, left used and untended to and evoking a sense of mystery and nostalgia.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (2, 4): (
        "Hallway",
        [
            "A narrow hallway stretches out before you. Dust particles dance in the faint light filtering through a distant window.",
            "The corridor, adorned with a touch of antique elegance, hints at the passage of time, whose walls whisper of a tale you do not know.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 4): (
        "Hallway",
        [
            "The hallway continues, adorned with antique sconces that cast flickering shadows on the walls. It feels like a journey through time.",
            "The hallway, with its flickering lights and aged walls, exudes an ambiance of mystery and the surreal.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (6, 4): (
        "Hallway",
        [
            "You walk further down the hallway through the towering arc, and the floorboards creak under your weight. The walls are adorned with old family portraits, their eyes seemingly following your every move.",
            "The hallway, lined with portraits of generations past, evokes a sense of familial history and a touch of intrigue.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_1"},
    ),
    (4, 4): (
        "Bedroom",
        [
            "You enter a spacious bedroom. Moonlight spills through the curtains, revealing a room frozen in time.",
            "The bedroom, frozen in an ageless elegance, captures a moment suspended in time, a blend of medieval charm and modern luxury.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (5, 4): (
        "Bedroom",
        [
            "The room holds an air of faded elegance. Tattered curtains billow gently near a cracked window.",
            "There's a sense of melancholy in the air. This part of the bedroom whispers the tales of a bygone era, a mix of dreams and the echoes of the past.",
            "You look at a magical archway.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (7, 4): (
        "Dressing Room",
        [
            "As you step into this section, you find yourself in a dressing room. Faded mirrors and racks of vintage clothing give a glimpse into lives from a bygone era.",
            "The dressing room seems like a capsule of time, filled with whispers of elegant fashion and old tales.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_1"},
    ),
    (7, 5): (
        "Dressing Room",
        [
            "This corner of the dressing room holds an air of mystery. Forgotten accessories and jewelry boxes lay scattered, telling silent tales of the past.",
            "The dim light casts an enigmatic glow on the forgotten trinkets.",
            {
                "grab": "You adore an intricate statue of a beautiful girl staring into the distance. You notice she is wearing a faintly glowing piece of jewelry."
            },
        ],
        {"walk": go, "grab": (grab, "rune_2")},
        {"walk": "opened_room_1"},
    ),
    (3, 3): (
        "Ancient Library",
        [
            "You discover a hidden room, its walls adorned with enigmatic symbols. The air is thick with ancient secrets.",
            "This hidden room, filled with cryptic symbols and arcane marks, carries an aura of arcane mysticism and ancient enigmas.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_4"},
    ),
    (3, 2): (
        "Ancient Library",
        [
            "You enter a hidden room filled with shelves of old tomes and artifacts. The knowledge within these walls is palpable.",
            "This hidden room is a sanctuary of knowledge, a blend of forgotten wisdom and a touch of intellectual allure.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_4"},
    ),
    (3, 1): (
        "Ancient Library",
        [
            "The room exudes an eerie atmosphere. Dusty shelves and forgotten relics line the space, hinting at stories long past.",
            "The shadows whisper tales of a shadowed past, a mix of ancient artifacts and a touch of the supernatural.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_4"},
    ),
    (4, 1): (
        "Void",
        [
            "Stepping into this room, you're engulfed by darkness. It's as if time itself has taken refuge here.",
            "This hidden room is a sanctuary of darkness, a blend of obscurity and a touch of the unknown, where time seems to stand still.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_4"},
    ),
    (5, 1): (
        "Void",
        [
            "The atmosphere feels serene. The walls whisper forgotten secrets. The very air feels charged with an ancient energy.",
            "This hidden room is a tapestry of forgotten whispers, a blend of ancient tales and a touch of ethereal energy.",
            {
                "grab": "You notice a singular glowing golden scroll hovering in front of you in the middle of the room, illuminating itself."
            },
        ],
        {"walk": go, "grab": (grab, "scroll_of_eternity")},
        {"walk": "opened_room_4"},
    ),
    (3, 5): (
        "Lobby",
        [
            "The corridor opens up into a grand lobby with high ceilings and marble pillars. The chandeliers above cast a warm glow, illuminating the space.",
            "The lobby, a fusion of marble and intricate chandeliers, echoes with the footsteps of countless visitors from another time.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 6): (
        "Lobby",
        [
            "You are cast in awe at the beauty of the architecture and marvel of the situation.",
            "You gently gaze down the path you are walking.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 7): (
        "Lobby",
        [
            "You find yourself in a long lobby that extends into the distance.",
            "You look at the numerous fish swimming around you, as you are now shaded behind blue light and cast into an aquarium.",
            "As you walk you slowly leave the fishes behind with a heavy heart.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 8): (
        "Entrance",
        [
            "You stand before the massive main door, its wood weathered by time.",
            "It stands guarding the entrance to the mansion, is a blend of ancient wood and a touch of mystery, beckoning you to unlock its secrets and venture outside.",
            {
                "grab": "You spot a glowing green rune on the shoe-drawer with '83Dr00M' inscribed on it. Someone must have left it there."
            },
        ],
        {"walk": go, "grab": (grab, "rune_1")},
        {"walk": "game_pass"},
    ),
    (2, 8): (
        "Entrance",
        [
            "You discover a concealed door, its outline barely visible amidst the grandeur of the mansion. Five slots of mystical origin are laden on its elegant surface, like it is missing something.",
            "Maybe it is the hidden door, a tapestry of hidden wonders, whispers the promise of secrets unveiled and a touch of elusive allure.",
            {},
        ],
        {"walk": go},
        {"walk": "end_game_opened"},
    ),
    (1, 8): (
        "Fountain of Wonders",
        [
            "You arrive at a magical fountain, its waters shimmering under the moonlight. The air is thick with anticipation as you stand before the finale of your journey.",
            "The fountain, a fusion of magic and moonlight, beckons you to the end of your adventure, a touch of enchantment in the air.",
            {},
        ],
        {},
        {"walk": "end_game_cleared"},
    ),
    (4, 8): (
        "Porch",
        [
            "You step onto a spacious porch that overlooks the surrounding grounds. The night sky is mesmerizing, and a sense of serenity washes over you.",
            "The porch, an open embrace of the night, whispers tales of the moon and stars, a blend of tranquility and a touch of celestial wonder.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (5, 8): (
        "Porch",
        [
            "This part of the porch is bathed in the soft glow of lanterns, creating a calming ambiance.",
            "A gentle breeze carries the scent of blooming flowers. The lantern-lit porch beckons you to linger, a blend of soft lights and a touch of floral fragrances.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (6, 8): (
        "Porch",
        [
            "As you step onto this section of the porch, you're greeted by the sound of rustling leaves and distant whispers of the wind.",
            "The porch, a symphony of nature, invites you to pause and listen, a blend of whispers and a touch of natural harmony.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (7, 8): (
        "Porch",
        [
            "The porch opens up to a charming garden, bathed in the soft glow of moonlight. The scent of blooming flowers dances on the air.",
            "The moonlit garden, a canvas of night, whispers tales of petals and magic, a blend of blossoms and a touch of ethereal beauty.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (8, 8): (
        "Lawn",
        [
            "The Lawn is expansive and bathed in the soft glow of moonlight. The scent of blooming flowers dances on the air.",
            "The moonlit garden, a canvas of night, whispers tales of petals and magic, a blend of blossoms and a touch of ethereal beauty.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (9, 8): (
        "Porch",
        [
            "You find yourself on an expansive porch, the moonlight casting intricate patterns on the ground. The night seems alive with its own secrets.",
            "The moon-kissed porch, an expanse of shadows and moonbeams, invites you to explore, a blend of mystery and a touch of lunar enchantment.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (10, 8): (
        "Grain House",
        [
            "You stand before a silo or grain house, its wooden structure weathered by time. It's a place steeped in rustic charm and history.",
            "This silo/grain house, a testament to the passage of time, holds a blend of rustic vibes and a touch of agricultural legacy.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (9, 7): (
        "Stable",
        [
            "A sturdy door stands before you, slightly ajar. The wood is worn, hinting at the many hands that have touched it.",
            "The door, a guardian of the unknown, offers a glimpse of what lies beyond, a blend of wood and a touch of enigma.",
            {
                "grab": "You find that the door to the silo is keyed in with a keychain with a faintly glowing ornament with the inscription :- 'Not where the master lays his head to sleep, Yet where duties are fulfilled and secrets keep.'."
            },
        ],
        {"walk": go, "grab": (grab, "rune_3")},
        {"walk": "opened_room_2"},
    ),
    (9, 6): (
        "Stable",
        [
            "You step into a humble stable area, surrounded by the scent of hay and the sound of soft knickers.",
            "The stable, a haven for gentle beasts, echoes with a blend of rural simplicity and a touch of equine grace.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_2"},
    ),
    (3, 9): (
        "Living Room",
        [
            "You enter a living room adorned with antique furniture and faded tapestries. The crackling fireplace creates a cozy ambiance.",
            "The living room, a blend of nostalgia and comfort, whispers tales of bygone eras, a touch of warmth in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 10): (
        "Living Room",
        [
            "This part of the living room holds an air of sophistication. Old books and a grand piano hint at past gatherings.",
            "The living room, a blend of elegance and whispers of music, invites you to linger, a touch of refinement in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 11): (
        "Living Room",
        [
            "You step into a section of the living room that echoes with laughter and lively conversations. The walls have witnessed joyous occasions.",
            "The living room, a blend of joy and echoes of laughter, beckons you to celebrate, a touch of mirth in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (3, 12): (
        "Living Room",
        [
            "As you walk through this part of the living room, you're enveloped by a sense of coziness. A worn armchair beckons.",
            "The living room, a blend of warmth and the promise of a good book, invites you to unwind, a touch of comfort in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (4, 12): (
        "Kitchen",
        [
            "You find yourself in a bustling kitchen, pots and pans clanging, and the aroma of cooked meals filling the air.",
            "The kitchen, a haven of culinary activity, whispers tales of shared meals and laughter, a blend of flavors and a touch of camaraderie.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (5, 12): (
        "Kitchen",
        [
            "This part of the kitchen exudes a sense of nostalgia. An old recipe book lies open on the counter.",
            "The kitchen, a blend of culinary history and the aroma of nostalgia, invites you to explore, a touch of heritage in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (6, 12): (
        "Kitchen",
        [
            "You step into the heart of the kitchen, where the aroma of freshly baked goods welcomes you. It's a place of creativity and nourishment.",
            "The kitchen, a blend of culinary artistry and the promise of a good meal, beckons you to partake, a touch of delight in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (7, 12): (
        "Kitchen",
        [
            "This part of the kitchen holds the organized chaos of a well-used space. Utensils are neatly arranged, and the stove is ready for action.",
            "The kitchen, a blend of order and the hustle of culinary endeavors, invites you to explore, a touch of culinary magic in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (5, 13): (
        "Servant Quarters",
        [
            "You stand before a door, slightly ajar, revealing a glimpse of what lies beyond. The wood is worn, hinting at the many hands that have turned its handle.",
            "The door, a guardian of mysteries, whispers tales of the unexplored, a blend of wood and a touch of enigma.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "opened_room_3"},
    ),
    (5, 14): (
        "Servant Quarters",
        [
            "You enter a modest space that once housed the servants. The room is simple, with small beds neatly made and personal belongings carefully arranged.",
            "The servant quarters, a blend of simplicity and a touch of humble existence, whispers tales of the unsung heroes, a touch of dedication in the air.",
            {
                "grab": "You spot a faint glowing ore in one corner of the room. You are quite intrigued at its presence. You spot what is written on its back, saying 'For where one begins, one must end!'"
            },
        ],
        {"walk": go, "grab": (grab, "rune_4")},
        {"walk": "opened_room_3"},
    ),
    (7, 11): (
        "Cafe",
        [
            "You step into a charming cafe within the mansion, its walls adorned with vintage posters and the scent of coffee in the air.",
            "The cafe, a blend of caffeine and artistic flair, whispers tales of creativity, a touch of inspiration in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (8, 12): (
        "Open Terrace Cafe",
        [
            "This part of the mansion opens up to an open terrace cafe. The night sky is mesmerizing, and a sense of serenity washes over you.",
            "The terrace cafe, an open embrace of the night, whispers tales of the moon and stars, a blend of tranquility and a touch of celestial wonder.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
    (10, 9): (
        "Sitting Area",
        [
            "This part of the mansion houses a charming sitting area. The soft glow of lamps adds a cozy ambiance to the room.",
            "The sitting area, a blend of comfort and elegance, invites you to linger, a touch of warmth in the air.",
            {},
        ],
        {
            "walk": go,
        },
        {"walk": "game_pass"},
    ),
}


"""Renders game screen with map, player info, and current node details.

Displays title banner, HUD with inventory and commands, node content, 
available actions, and directions. Left side shows detailed node info.
Right side displays map with player's position marked.

Args:
 game_map: GameMap instance
 player: Player instance
 c_node: Current Node instance player is on
 com: Previous command and execution status  

Returns: None
"""


# lhs + 9 spaces || 9spaces + map
def blit_screen(game_map, player, c_node, com):
    # sourcery skip: low-code-quality
    # \n

    title = [
        " ____   .__   __.  ______  .______       _  _    .______   .___  ___.  ____   .__   __.  ______              ",
        "|___ \  |  \ |  | |____  | |   _  \     | || |   |   _  \  |   \/   | |___ \  |  \ |  | |____  |             ",
        "  __) | |   \|  |     / /  |  |_)  |    | || |_  |  |_)  | |  \  /  |   __) | |   \|  |     / /              ",
        " |__ <  |  . `  |    / /   |      /     |__   _| |   ___/  |  |\/|  |  |__ <  |  . `  |    / /               ",
        " ___) | |  |\   |   / /    |  |\  \----.   | |   |  |      |  |  |  |  ___) | |  |\   |   / /                ",
        "|____/  |__| \__|  /_/     | _| `._____|   |_|   | _|      |__|  |__| |____/  |__| \__|  /_/                 ",
    ]

    # \n * 3

    hud = [
        "-" * 109,
        f"You are in :- The {c_node.type}".ljust(109),  # \n
        f"Player inventory :- -] {' [] '.join(player.inventory)} [-".ljust(
            109
        ),  # \n * 2
        "Inbuilt commands :- teleport : teleport <location> (eg. teleport cabinet)".ljust(
            109
        ),
        "-" * 109,
    ]

    # \n

    content = []
    for line in c_node.content:
        if type(line) == str:
            if len(line) > 109:
                content.extend(
                    [f"{line[:107]}-".ljust(109), f"-{line[107:]}".ljust(109)]
                )
            else:
                content.append(line.ljust(109))

        else:
            for line in line.values():
                if len(line) > 109:
                    content.extend(
                        [f"{line[:107]}-".ljust(109), f"-{line[107:]}".ljust(109)]
                    )
                else:
                    content.append(line.ljust(109))

    free_line = [" " * 109]
    left_hand_list_unbuffered = (
        free_line
        + title
        + free_line * 3
        + hud
        + free_line * 2
        + content
        + free_line * 4
        + [f'Possible actions :- -] {" [] ".join(c_node.actions)} [-'.ljust(109)]
        + [
            f"Available directions :- {', '.join([x for x in c_node.possible_Directions() if x])}".ljust(
                109
            )
        ]
    )
    lhl = (
        left_hand_list_unbuffered
        + free_line * (40 - len(left_hand_list_unbuffered))
        + [f"Previous Command :- {com[0]}".ljust(109)]
        + [f"Status of execution :- {com[1]}".ljust(109)]
    )
    rhl = game_map

    terminal = (
        ["-" * 200]
        + [str(f"{lhl[i]}||" + " " * 30 + rhl[i]).ljust(109) for i in range(42)]
    ) + ["-" * 200]
    return "\n".join(terminal)
## END
